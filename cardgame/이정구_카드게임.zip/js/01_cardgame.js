var frontOfCardImgs = $('.frnotOfCards img');
var backOfCardImgs = $('.backOfCards img');
var cardData = {}; // 카드 정보들 담을 객체

// 게임 시작
placeOnScreenCards();

$('.backOfCards img').click(function(){
    // 카드 비교
    clickCards(this);
    
    //게임 종료 
    succeseGame();
});

// 리스타트
$('.restart_btn').click(function(){
    location.reload();
});

// 카드 랜덤으로 담기
function randomOfCards(){
    var imgName = [];
    for(var i=0;i<frontOfCardImgs.length/2;i++){
        imgName[i] = i+1;
    }
    imgName = imgName.concat(imgName);
    imgName.sort(function(a, b){
        return 0.5 - Math.random();
    });
    return imgName;
}

// 화면에 카드 배치
function placeOnScreenCards(){
    var imgName = randomOfCards();
    for(var i=0;i<frontOfCardImgs.length;i++){
        frontOfCardImgs.eq(i).attr({'src':'images/img'+imgName[i]+'.png','data-num':imgName[i]});
    }
    /*카드 배치하고 앞면 보여줬다가 0.8초 후 뒤집기*/
    setTimeout(function(){
        animateHideCard(frontOfCardImgs,backOfCardImgs);
    },800);
}

// 카드 보여주는 애니메이션
function animateShowCard(frontOfCard,backOfCard){
    frontOfCard.removeClass('flippingAnimationCard');
    backOfCard.removeClass('flippingAnimationCard');
}

// 카드 가리는 애니메이션
function animateHideCard(frontOfCard,backOfCard){
    frontOfCard.addClass('flippingAnimationCard');
    backOfCard.addClass('flippingAnimationCard');
}

// 클릭시 cardData 객체에 담을 카드 정보들
function cardInformation(object, clickImg){
    cardData[object] = {}
    cardData[object].backOfCardNumber = $(clickImg).index();
    cardData[object].cardData = frontOfCardImgs.eq(cardData[object].backOfCardNumber).attr('data-num');
    cardData[object].frontOfCardImg = frontOfCardImgs.eq(cardData[object].backOfCardNumber);
    cardData[object].backOfCardImg = $(clickImg);
}

// 카드들을 비교하고 비교한 내용에 따른 결과
function compareCards(){
    if(cardData.firstCard.backOfCardNumber==cardData.seccondCard.backOfCardNumber){
        cardData.seccondCard = {}
    }else{
        if(cardData.firstCard.cardData==cardData.seccondCard.cardData){
            /*뒤집은 두장의 카드가 같은 카드일 경우 clearCard라는 클래스 추가*/
            cardData.firstCard.backOfCardImg.addClass('clearCard');
            cardData.seccondCard.backOfCardImg.addClass('clearCard');
            
        }else{
            // 다른 카드를 differentCards 객체에 넣어서 cardData 객체에 새로운 카드 정보가 들어가도 오류가 나지 않도록 함.
            var differentCards = {
                mustHideCard : [
                    cardData.firstCard.frontOfCardImg,
                    cardData.firstCard.backOfCardImg,
                    cardData.seccondCard.frontOfCardImg,
                    cardData.seccondCard.backOfCardImg
                ]
            }
            // 두 카드가 다를경우 0.4초뒤에 카드가 뒤집어짐(0.4초 텀을 줌으로써 2번째 카드가 뒤집어질 시간을 확보)
            setTimeout(function(){
                for(var i=0; i<differentCards.mustHideCard.length; i++){
                    differentCards.mustHideCard[i].addClass('flippingAnimationCard');
                }
            },400);
        }
        // 비교가 끝나면 cardData 객체를 비워줌
        cardData = {}
    }
}

// 카드 클릭 이벤트 내용
function clickCards(clickImg){
    if($.isEmptyObject(cardData)==true){
        cardInformation("firstCard", clickImg);
        animateShowCard(cardData.firstCard.frontOfCardImg,$(clickImg));
    }else if($.isEmptyObject(cardData)==false){
        cardInformation("seccondCard", clickImg);
        animateShowCard(cardData.seccondCard.frontOfCardImg,$(clickImg));
        compareCards();
    }
}

// 게임 종료 조건
function succeseGame(){
    if($('.clearCard').length==frontOfCardImgs.length){
        setTimeout(function(){
            $('#cardgame').fadeOut('fast');
            $('.succese').fadeIn('slow');
        },700);
    }
}

// 이미지 드래그 방지
$('img').on('dragstart',function(event){
    event.preventDefault();
});








